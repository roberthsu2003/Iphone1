//
//  CityCell.swift
//  project13_1
//
//  Created by 徐國堂 on 2022/2/27.
//

import UIKit

class CityCell: UICollectionViewCell {
    @IBOutlet var cityImageView:UIImageView!
}

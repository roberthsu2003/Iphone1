//
//  SiteViewCell.swift
//  project16
//
//  Created by 徐國堂 on 2022/3/20.
//

import UIKit

class SiteViewCell: UITableViewCell {

    @IBOutlet var siteName:UILabel!
    @IBOutlet var total:UILabel!
    @IBOutlet var rent:UILabel!
    @IBOutlet var returns:UILabel!
    @IBOutlet var mday:UILabel!

}

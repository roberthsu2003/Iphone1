//
//  CityCell.swift
//  project7
//
//  Created by 徐國堂 on 2022/1/16.
//

import UIKit

class CityCell: UITableViewCell {
    @IBOutlet var cityLabel:UILabel!
    @IBOutlet var countryLabel:UILabel!
    @IBOutlet var continentLabel:UILabel!
    @IBOutlet var cityImageView:UIImageView!
    
   
}

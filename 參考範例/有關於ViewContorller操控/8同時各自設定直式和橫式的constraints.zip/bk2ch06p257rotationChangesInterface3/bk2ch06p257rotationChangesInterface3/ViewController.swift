

import UIKit

class ViewController: UIViewController {
                            
    // hey, where did all the code go? 
    // Surprise, conditional constraints in the nib!
    // solves the whole problem, badda bing badda boom
    

}


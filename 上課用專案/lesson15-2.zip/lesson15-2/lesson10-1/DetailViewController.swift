//
//  DetailViewController.swift
//  lesson15-2
//
//  Created by 徐國堂 on 2021/2/4.
//

import UIKit

class DetailViewController: UIViewController {
    @IBOutlet var cityImageView:UIImageView!
    var cityImageName:String!
    var cityName:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = cityName
        cityImageView.image = UIImage(named: cityImageName)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

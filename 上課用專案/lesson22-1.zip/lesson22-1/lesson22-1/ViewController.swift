//
//  ViewController.swift
//  lesson22-1
//
//  Created by 徐國堂 on 2021/3/2.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        DataSource.copyFilesToDocuments()
        
    }


}


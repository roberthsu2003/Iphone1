//
//  ViewController.swift
//  lesson7
//
//  Created by 徐國堂 on 2020/12/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        //view.backgroundColor = UIColor(red: 0, green: 1.0, blue: 0, alpha: 1)
    }


}


//
//  RateViewController.swift
//  lesson18-1
//
//  Created by 徐國堂 on 2021/2/9.
//

import UIKit

class RateViewController: UIViewController {
    var num = 50;
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

  

}

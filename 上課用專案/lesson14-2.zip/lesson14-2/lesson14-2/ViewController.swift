//
//  ViewController.swift
//  lesson14-2
//
//  Created by 徐國堂 on 2021/1/26.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}


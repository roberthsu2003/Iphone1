//
//  ViewController.swift
//  DataSource
//
//  Created by t1 on 2019/2/17.
//  Copyright © 2019年 gjun. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let datasource1 = DataSource.singleton;
        let datasource2 = DataSource.singleton;
        let datasource3 = DataSource.singleton;
    }


}


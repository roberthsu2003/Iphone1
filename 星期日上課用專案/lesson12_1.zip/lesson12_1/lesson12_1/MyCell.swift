//
//  MyCell.swift
//  lesson12_1
//
//  Created by 徐國堂 on 2021/6/6.
//

import UIKit

class MyCell: UICollectionViewCell {
    @IBOutlet var nameLabel:UILabel!
}

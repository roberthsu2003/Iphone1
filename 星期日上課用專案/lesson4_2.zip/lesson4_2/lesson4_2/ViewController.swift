//
//  ViewController.swift
//  lesson4_2
//
//  Created by 徐國堂 on 2021/4/11.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func leftClick(_ sender:UIButton){
        print("left click")
    }
    
    @IBAction func rightClick(_ sender:UIButton){
        print("right click")
    }


}


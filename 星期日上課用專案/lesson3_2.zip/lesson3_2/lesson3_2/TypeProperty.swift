import Foundation
struct SomeStructure{
    //type property
    static var storedTypeProperty = "Some value"
    static var computedTypeProperty:Int {
        return 1
    }
}

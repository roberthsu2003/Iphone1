//
//  City.swift
//  lesson15_2
//
//  Created by 徐國堂 on 2021/7/14.
//

import Foundation
class City{
    var city:String!
    var continent:String!
    var country:String!
    var image:String!
    var local:String!
    var latitude:Double!
    var longitude:Double!
    var url:String!
    var userRate:String?
}

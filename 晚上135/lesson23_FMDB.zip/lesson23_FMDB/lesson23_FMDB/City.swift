import Foundation

class City{
    var cityName:String
    var url:String
    var country:String
    
    init(cityName:String, url:String, country:String){
        self.cityName = cityName
        self.url = url
        self.country = country
    }
}

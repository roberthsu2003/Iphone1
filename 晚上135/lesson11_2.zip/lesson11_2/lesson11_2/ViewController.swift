//
//  ViewController.swift
//  lesson11_2
//
//  Created by 徐國堂 on 2021/7/2.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        print("ViewController內的View全部可以使用了")
    }


}

